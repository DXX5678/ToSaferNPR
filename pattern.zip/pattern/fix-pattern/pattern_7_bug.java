public class Demo {
    public static void main(String[] args){
        if(temp.getStartTime() <= MainScheduler.counter && temp.getCpuBurst() == temp.getInitialCpuBurst())
        {
            System.out.println();
        }
    }
}