/**
 * @author 丁旭行
 */
public class B_Pattern {
	int main(){
		System.arraycopy(modelviewMatrix, 0, mesh.getUniformMatrices(), 0, v.getSizeInFloats());
	}
}
