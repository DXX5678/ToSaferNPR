/**
 * @author 丁旭行
 */
public class B_Pattern {
	final String schema = getSchema() == null ? null : getSchema().getName();
}
