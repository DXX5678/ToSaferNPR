/**
 * @author 丁旭行
 */
public class B_Pattern {
	String schema = getSchema() == null ? null : getSchema().getName();
}
