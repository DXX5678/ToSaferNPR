/**
 * @author 丁旭行
 */
public class B_Pattern {
	int main(){
		if (count < -1 || count > availableData + 1 || count % zoom == 0) {
			continue;
		}
	}
}
