/**
 * @author 丁旭行
 */
public class B_Pattern {
	int main(){
		int curIdx = 0;
		int len = 0;
		if(curIdx < len){
			curIdx++;
		}
	}
}
