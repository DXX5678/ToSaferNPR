/**
 * @author 丁旭行
 */
public class B_Pattern {
	int main(){
		if (count % zoom == 0) {
			continue;
		}
	}
}
