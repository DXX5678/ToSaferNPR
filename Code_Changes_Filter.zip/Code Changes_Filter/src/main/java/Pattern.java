/**
 * @author 丁旭行
 */
public class Pattern {
    public static CodeChanges pattern1 = new CodeChanges();
    public static CodeChanges pattern2 = new CodeChanges();
    public static CodeChanges pattern3 = new CodeChanges();
    public static CodeChanges pattern4 = new CodeChanges();
    public static CodeChanges pattern5 = new CodeChanges();
    public static CodeChanges pattern6 = new CodeChanges();
    public static CodeChanges pattern7 = new CodeChanges();
    public static CodeChanges pattern8 = new CodeChanges();
    public static CodeChanges pattern9 = new CodeChanges();
    public static CodeChanges pattern10 = new CodeChanges();
    public static CodeChanges pattern11 = new CodeChanges();
    public static CodeChanges pattern12 = new CodeChanges();
    public static CodeChanges pattern13 = new CodeChanges();
    public static CodeChanges pattern14 = new CodeChanges();
    public static CodeChanges pattern15 = new CodeChanges();
    public static CodeChanges pattern16 = new CodeChanges();
    public static CodeChanges pattern17 = new CodeChanges();
    static {
        pattern1.codeChanges.add(new CodeChange("insert", "nonNull", "InfixExpression"));
        pattern1.codeChanges.add(new CodeChange("update"));
        pattern1.codeChanges.add(new CodeChange("delete"));
        pattern2.codeChanges.add(new CodeChange("insert", "nonNull", "METHOD_INVOCATION_ARGUMENTS"));
        pattern2.codeChanges.add(new CodeChange("delete"));
        pattern3.codeChanges.add(new CodeChange("insert", "ASSIGNMENT_OPERATORNullLiteral", "Block"));
        pattern4.codeChanges.add(new CodeChange("insert", "nonNull", "METHOD_INVOCATION_ARGUMENTS"));
        pattern5.codeChanges.add(new CodeChange("insert", "final", "VariableDeclarationStatement"));
        pattern6.codeChanges.add(new CodeChange("insert", "IfStatementInfixExpressionNullLiteral", "Block"));
        pattern7.codeChanges.add(new CodeChange("update", "INFIX_EXPRESSION_OPERATOR"));
        pattern8.codeChanges.add(new CodeChange("insert", "InfixExpression", "IfStatement"));
        pattern8.codeChanges.add(new CodeChange("insert", "||", "InfixExpression"));
        pattern9.codeChanges.add(new CodeChange("insert", "IfStatementThrowStatement", "Block"));
        pattern10.codeChanges.add(new CodeChange("insert", "nonNull", "InfixExpression"));
        pattern10.codeChanges.add(new CodeChange("delete"));
        pattern11.codeChanges.add(new CodeChange("insert", "IfStatement", "Block"));
        pattern11.codeChanges.add(new CodeChange("move", "nonNull", "IfStatement"));
        pattern12.codeChanges.add(new CodeChange("insert", "PrimitiveType", "CastExpression"));
        pattern13.codeChanges.add(new CodeChange("insert", "ConditionalExpression", "VariableDeclarationFragment"));
        pattern14.codeChanges.add(new CodeChange("insert", "IfStatementReturnStatementNullLiteral", "Block"));
        pattern15.codeChanges.add(new CodeChange("update", "PrimitiveType"));
        pattern16.codeChanges.add(new CodeChange("update", "BooleanLiteral"));
        pattern17.codeChanges.add(new CodeChange("update", "SimpleName"));
    }
}
