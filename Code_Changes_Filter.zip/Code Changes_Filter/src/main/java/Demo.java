import com.github.gumtreediff.actions.EditScript;
import com.github.gumtreediff.actions.EditScriptGenerator;
import com.github.gumtreediff.actions.SimplifiedChawatheScriptGenerator;
import com.github.gumtreediff.actions.model.Action;
import com.github.gumtreediff.gen.javaparser.JavaParserGenerator;
import com.github.gumtreediff.gen.jdt.JdtTreeGenerator;
import com.github.gumtreediff.matchers.MappingStore;
import com.github.gumtreediff.matchers.Matcher;
import com.github.gumtreediff.matchers.Matchers;
import com.github.gumtreediff.tree.Tree;

import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * 尝试将代码变更模板化
 *
 * @author 丁旭行
 */
public class Demo {
    public static void main(String[] args) {
        String bugFile = "D:\\writing_paper\\new-dataset\\raw_data\\sequencer-train\\19833_bug.java";
        String fixFile = "D:\\writing_paper\\new-dataset\\raw_data\\sequencer-train\\19833_fix.java";
        ArrayList<ArrayList<String>> results = Utils.getChanges(bugFile, fixFile);
        if(results == null){
            System.out.println("样本提取代码变更失败");
            return;
        }
        for (ArrayList<String> result : results){
            for (String a : result){
                System.out.println(a);
            }
        }
    }
}
