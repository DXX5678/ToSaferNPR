import java.util.Objects;

/**
 * @author 丁旭行
 */
public class CodeChange {
    public String actionType = "";
    public String content = "nonNull";
    public String location = "";

    public CodeChange(String actionType, String content, String location){
        this.actionType = actionType;
        this.content = content;
        this.location = location;
    }

    public CodeChange(String actionType, String content){
        this.actionType = actionType;
        this.content = content;
    }

    public CodeChange(String actionType){
        this.actionType = actionType;
    }

    @Override
    public String toString() {
        return "CodeChange{" +
                "actionType='" + actionType + '\'' +
                ", content='" + content + '\'' +
                ", location='" + location + '\'' +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        CodeChange that = (CodeChange) o;
        return actionType.equals(that.actionType) && content.equals(that.content) && location.equals(that.location);
    }

    @Override
    public int hashCode() {
        return Objects.hash(actionType, content, location);
    }
}
