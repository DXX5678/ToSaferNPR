import java.util.HashMap;

/**
 * @author 丁旭行
 */
public class Main {
    public static void main(String[] args) {
        String path = args[0];
        int num = Integer.parseInt(args[2]);
        HashMap<Integer, Integer> dataset = Utils.sortDataset(path, num);
        String resultFile = args[1];
        Utils.writeJson(resultFile, dataset);
    }
}
