import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.github.gumtreediff.actions.EditScript;
import com.github.gumtreediff.actions.EditScriptGenerator;
import com.github.gumtreediff.actions.SimplifiedChawatheScriptGenerator;
import com.github.gumtreediff.actions.model.Action;
import com.github.gumtreediff.gen.javaparser.JavaParserGenerator;
import com.github.gumtreediff.gen.jdt.JdtTreeGenerator;
import com.github.gumtreediff.matchers.MappingStore;
import com.github.gumtreediff.matchers.Matcher;
import com.github.gumtreediff.matchers.Matchers;
import com.github.gumtreediff.tree.Tree;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.*;

import static java.lang.String.join;

/**
 * @author 丁旭行
 */
public class Utils {
    public static ArrayList<ArrayList<String>> getChanges(String bugFile, String fixFile) {
        ArrayList<ArrayList<String>> results = new ArrayList<ArrayList<String>>();
        Tree bugTree = null;
        try {
            ;
            bugTree = new JdtTreeGenerator().generate(new FileReader(bugFile)).getRoot();
            //bugTree = new JavaParserGenerator().generate(new FileReader(bugFile)).getRoot();
            if (bugTree == null) {
                return null;
            }
        } catch (Exception e) {
            //e.printStackTrace();
            return null;
        }
        Tree fixTree = null;
        try {
            fixTree = new JdtTreeGenerator().generate(new FileReader(fixFile)).getRoot();
            //fixTree = new JavaParserGenerator().generate(new FileReader(fixFile)).getRoot();
            if (fixTree == null) {
                return null;
            }
        } catch (Exception e) {
            //e.printStackTrace();
            return null;
        }
        Matcher defaultMatcher = Matchers.getInstance().getMatcher();
        MappingStore mappings = null;
        mappings = defaultMatcher.match(bugTree, fixTree);
        if (mappings == null) {
            return null;
        }
        EditScriptGenerator editScriptGenerator = new SimplifiedChawatheScriptGenerator();
        EditScript actions = editScriptGenerator.computeActions(mappings);
        List<Action> actionsList = actions.asList();
        for (Action action : actionsList) {
            ArrayList<String> result = new ArrayList<String>();
            String change = action.toString();
            String[] changes = change.split(String.valueOf('\n'));
            for (String s : changes) {
                if (!s.trim().contains("===") && !s.trim().contains("---")) {
                    result.add(s.trim());
                }
            }
            results.add(result);
        }
        return results;
    }

    public static HashMap<Integer, Integer> sortDataset(String dataset, int num) {
        HashMap<Integer, Integer> results = new HashMap<Integer, Integer>();
        File dir = new File(dataset);
        if (!dir.exists()) {
            System.out.println("目录不存在");
            return null;
        }
        int total = (Objects.requireNonNull(dir.listFiles()).length) / 2;
        System.out.println("原数据集共有" + total + "个样本");
        if(num+100000 < total){
            total = num+100000;
        }
        int totalAfter = 0;
        for (int i = 0+num; i < total; i++) {
            String bugFile = dataset + File.separator + i + "_bug.java";
            String fixFile = dataset + File.separator + i + "_fix.java";
            System.out.println(bugFile);
            System.out.println(fixFile);
            ArrayList<ArrayList<String>> changes = Utils.getChanges(bugFile, fixFile);
            if (changes==null){
                System.out.println("样本" + i + "提取代码变更失败");
                continue;
            }
            CodeChanges codeChanges = new CodeChanges(changes);
            if(codeChanges.codeChanges.isEmpty()){
                System.out.println("样本" + i + "创建代码变更对象失败");
                continue;
            }
            System.out.println("样本" + i + "创建对象成功");
            //System.out.println(Arrays.toString(codeChanges.codeChanges.toArray()));
            if(codeChanges.equals(Pattern.pattern1)){
                System.out.println("样本" + i + "符合模板1");
                results.put(i, 1);
                totalAfter++;
            }else if(codeChanges.equals(Pattern.pattern2)){
                System.out.println("样本" + i + "符合模板2");
                results.put(i, 2);
                totalAfter++;
            }else if(codeChanges.equals(Pattern.pattern3)){
                System.out.println("样本" + i + "符合模板3");
                results.put(i, 3);
                totalAfter++;
            }else if(codeChanges.equals(Pattern.pattern4)){
                System.out.println("样本" + i + "符合模板4");
                results.put(i, 4);
                totalAfter++;
            }else if(codeChanges.equals(Pattern.pattern5)){
                System.out.println("样本" + i + "符合模板5");
                results.put(i, 5);
                totalAfter++;
            }else if(codeChanges.equals(Pattern.pattern6)){
                System.out.println("样本" + i + "符合模板6");
                results.put(i, 6);
                totalAfter++;
            }else if(codeChanges.equals(Pattern.pattern7)){
                System.out.println("样本" + i + "符合模板7");
                results.put(i, 7);
                totalAfter++;
            }else if(codeChanges.equals(Pattern.pattern8)){
                System.out.println("样本" + i + "符合模板8");
                results.put(i, 8);
                totalAfter++;
            }else if(codeChanges.equals(Pattern.pattern9)){
                System.out.println("样本" + i + "符合模板9");
                results.put(i, 9);
                totalAfter++;
            }else if(codeChanges.equals(Pattern.pattern10)){
                System.out.println("样本" + i + "符合模板10");
                results.put(i, 10);
                totalAfter++;
            }else if(codeChanges.equals(Pattern.pattern11)){
                System.out.println("样本" + i + "符合模板11");
                results.put(i, 11);
                totalAfter++;
            }else if(codeChanges.equals(Pattern.pattern12)){
                System.out.println("样本" + i + "符合模板12");
                results.put(i, 12);
                totalAfter++;
            }else if(codeChanges.equals(Pattern.pattern13)){
                System.out.println("样本" + i + "符合模板13");
                results.put(i, 13);
                totalAfter++;
            }else if(codeChanges.equals(Pattern.pattern14)){
                System.out.println("样本" + i + "符合模板14");
                results.put(i, 14);
                totalAfter++;
            }else if(codeChanges.equals(Pattern.pattern15)){
                System.out.println("样本" + i + "符合模板15");
                results.put(i, 15);
                totalAfter++;
            }else if(codeChanges.equals(Pattern.pattern16)){
                System.out.println("样本" + i + "符合模板16");
                results.put(i, 16);
                totalAfter++;
            }else if(codeChanges.equals(Pattern.pattern17)){
                System.out.println("样本" + i + "符合模板17");
                results.put(i, 17);
                totalAfter++;
            }else{
                System.out.println("样本" + i + "不符合任何模板");
            }
        }
        System.out.println("过滤后数据集共有" + totalAfter + "个样本");
        return results;
    }

    public static void writeJson(String file, HashMap<Integer, Integer> data){
        ObjectMapper mapper = new ObjectMapper();
        String json = "";
        try {
            json = mapper.writeValueAsString(data);
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }
        System.out.println(json);
        try{
            FileWriter fileWriter = new FileWriter(file);
            fileWriter.write(json);
            fileWriter.close();
        }catch(Exception e){
            e.printStackTrace();
        }
    }
}
