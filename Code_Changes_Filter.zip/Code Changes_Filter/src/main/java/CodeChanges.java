import java.util.ArrayList;
import java.util.HashSet;

/**
 * @author 丁旭行
 */
public class CodeChanges {
    public HashSet<CodeChange> codeChanges = new HashSet<CodeChange>();

    public CodeChanges() {

    }

    public CodeChanges(ArrayList<ArrayList<String>> changes) {
        for (ArrayList<String> change : changes) {
            String actionType = "";
            String content = "";
            String location = "";
            if (change.get(0).startsWith("insert")) {
                int start = 2;
                actionType = "insert";
                content = change.get(1).split(" ")[0];
                location = change.get(change.size() - 2).split(" ")[0];
                if (content.contains(":")) {
                    content = content.substring(0, content.indexOf(":"));
                }
                if ("ExpressionStatement".equals(content)) {
                    boolean flagA = false;
                    boolean flagN = false;
                    while (start < change.size() && !"to".equals(change.get(start))) {
                        if ("ASSIGNMENT_OPERATOR".equals(change.get(start))) {
                            flagA = true;
                        }
                        if ("NullLiteral".equals(change.get(start))) {
                            flagN = true;
                        }
                        start++;
                    }
                    if (flagA && flagN) {
                        content = "ASSIGNMENT_OPERATORNullLiteral";
                    }
                } else if ("Modifier".equals(content)) {
                    if ("final".equals(change.get(1).split(" ")[1])) {
                        content = "final";
                    } else {
                        continue;
                    }
                } else if ("IfStatement".equals(content)) {
                    if (!"to".equals(change.get(2))) {
                        StringBuilder temp = new StringBuilder(content);
                        while (start < change.size() && !"to".equals(change.get(start))) {
                            temp.append(change.get(start));
                            start++;
                        }
                        if (temp.toString().contains("InfixExpression") && temp.toString().contains("NullLiteral")) {
                            content = "IfStatementInfixExpressionNullLiteral";
                        } else if (temp.toString().contains("ThrowStatement")) {
                            content = "IfStatementThrowStatement";
                        } else if (temp.toString().contains("ReturnStatement") && temp.toString().contains("NullLiteral")) {
                            content = "IfStatementReturnStatementNullLiteral";
                        } else {
                            continue;
                        }
                    }
                } else if ("InfixExpression".equals(content)) {
                    if (!"to".equals(change.get(2))) {
                        continue;
                    }
                } else if ("PrimitiveType".equals(content)) {
                    if (!"to".equals(change.get(2))) {
                        continue;
                    }
                } else if ("ConditionalExpression".equals(content)) {
                    if (!"to".equals(change.get(2))) {
                        continue;
                    }
                } else if ("INFIX_EXPRESSION_OPERATOR".equals(content)) {
                    if ("||".equals(change.get(1).split(" ")[1]) || "|".equals(change.get(1).split(" ")[1]) || "&&".equals(change.get(1).split(" ")[1]) || "&".equals(change.get(1).split(" ")[1])) {
                        content = "||";
                    } else {
                        continue;
                    }
                } else {
                    StringBuilder temp = new StringBuilder(content);
                    while (start < change.size() && !"to".equals(change.get(start))) {
                        temp.append(change.get(start));
                        start++;
                    }
                    if (!temp.toString().contains("NullLiteral")) {
                        content = "nonNull";
                    }
                }
            } else if (change.get(0).startsWith("delete")) {
                actionType = "delete";
                content = "nonNull";
                location = "";
            } else if (change.get(0).startsWith("update")) {
                actionType = "update";
                content = "nonNull";
                location = "";
                for (String str : change) {
                    if (str.startsWith("INFIX_EXPRESSION_OPERATOR")) {
                        content = "INFIX_EXPRESSION_OPERATOR";
                        break;
                    } else if (str.startsWith("PrimitiveType")){
                        content = "PrimitiveType";
                        break;
                    } else if (str.startsWith("BooleanLiteral")){
                        content = "BooleanLiteral";
                        break;
                    } else if (str.startsWith("SimpleName")){
                        content = "SimpleName";
                        break;
                    }
                }
            } else if (change.get(0).startsWith("move")) {
                actionType = "move";
                content = "nonNull";
                location = change.get(change.size() - 2).split(" ")[0];
            }
            CodeChange codeChange = new CodeChange(actionType, content, location);
            this.codeChanges.add(codeChange);
        }
    }

    public void addCodeChange(CodeChange codeChange) {
        this.codeChanges.add(codeChange);
    }

    public boolean equals(CodeChanges codeChanges) {
        return this.codeChanges.containsAll(codeChanges.codeChanges);
    }
}
